package com.example.androidhelper.fragments;

public class Shakespeare {
	public static final String[] DIALOGUE = { "Android description", "IOs description", "DOS description",
			"Windows description" };
	public static String[] TITLES = { "Android", "IOs", "DOS", "Windows" };
}
