package com.ua.android_helper.swiftandroid;

import android.app.Activity;
import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.Toast;

public class MainActivity extends Activity implements OnCheckedChangeListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        CompoundButton compoundButton = (CompoundButton) findViewById(R.id.checkBox1);
        compoundButton.setOnCheckedChangeListener(this);
    }

    @Override
    public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
        Toast.makeText(this, "Все работает сейчас у нас " + arg1, Toast.LENGTH_LONG).show();
    }

}
