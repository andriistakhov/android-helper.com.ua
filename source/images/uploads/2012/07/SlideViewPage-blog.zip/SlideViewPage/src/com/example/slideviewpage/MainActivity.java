package com.example.slideviewpage;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends Activity {

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		LayoutInflater inflater = LayoutInflater.from(this);
		List<View> pages = new ArrayList<View>();

		View page = inflater.inflate(R.layout.page, null);
		TextView textView = (TextView) page.findViewById(R.id.text_view);
		textView.setText("�������� 1");
		pages.add(page);

		page = inflater.inflate(R.layout.page, null);
		textView = (TextView) page.findViewById(R.id.text_view);
		textView.setText("�������� 2");
		pages.add(page);

		page = inflater.inflate(R.layout.page, null);
		textView = (TextView) page.findViewById(R.id.text_view);
		textView.setText("�������� 3");
		pages.add(page);

		SamplePagerAdapter pagerAdapter = new SamplePagerAdapter(pages);
		ViewPager viewPager = new ViewPager(this);
		viewPager.setAdapter(pagerAdapter);
		viewPager.setCurrentItem(1);

		setContentView(viewPager);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}
}
