package com.example.service;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;

public class MainActivity extends Activity {

	@Override
	public void onCreate(final Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		Intent intent = new Intent(this, MyService.class);
		startService(intent.putExtra("time", 3).putExtra("label", "Call 1"));
		startService(intent.putExtra("time", 1).putExtra("label", "Call 2"));
		startService(intent.putExtra("time", 4).putExtra("label", "Call 3"));
	}

	@Override
	public boolean onCreateOptionsMenu(final Menu menu) {
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}
}
