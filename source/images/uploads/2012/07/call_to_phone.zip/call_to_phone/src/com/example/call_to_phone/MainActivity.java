package com.example.call_to_phone;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends Activity implements OnClickListener {

	private EditText callNumber;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		callNumber = (EditText) findViewById(R.id.editText1);
		Button callButton = (Button) findViewById(R.id.button1);
		callButton.setOnClickListener(this);

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}

	@Override
	public void onClick(View arg0) {
		if (callNumber != null) {
			String number = String.format("tel:%s", callNumber.getText().toString());
			startActivity(new Intent(Intent.ACTION_CALL, Uri.parse(number)));
		}
	}
}
