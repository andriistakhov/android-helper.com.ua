package com.android_helper.pagertabstripexample;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class FragmentView3 extends Fragment {
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View myView = inflater.inflate(R.layout.fragment_default, container, false);
		TextView text = (TextView) myView.findViewById(R.id.text);
		text.setText("Fragment View 3\n - ������ ��� android-helper.com.ua");
		return myView;
	}

}
