package com.ua.android_helper.send_message;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class SMSFun extends Activity {

	// Button to trigger sending the SMS
	Button aButton;
	// PendingIntent to tell the SMS app to notify us
	PendingIntent sentPI;
	// The intent action we are using
	String SENT = "SMS_SENT";
	// The BroadcastReceiver that we use to listen for the notification back
	BroadcastReceiver br;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		// Create the Pending Intent
		sentPI = PendingIntent.getBroadcast(this, 0, new Intent(SENT), 0);
		aButton = (Button) this.findViewById(R.id.button1);
		aButton.setOnClickListener(new Button.OnClickListener() {
			@Override
			public void onClick(View v) {
				SmsManager sms = SmsManager.getDefault();
				// send the message, passing in the pending intent, sentPI
				sms.sendTextMessage("1-212-555-1212", null, "Hi there", sentPI, null);
				registerReceiver(br, new IntentFilter(SENT));
			}
		});

		// In order to receive the results via the pending intent we need
		// to register a new BroadcastReceiver and pay attention to the various
		// values we could get back
		br = new BroadcastReceiver() {
			@Override
			public void onReceive(Context ctx, Intent intent) {
				switch (getResultCode()) {
					case Activity.RESULT_OK:
						Toast.makeText(getBaseContext(), "SMS sent", Toast.LENGTH_SHORT).show();
						break;
					case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
						Toast.makeText(getBaseContext(), "SMS: Generic failure", Toast.LENGTH_SHORT).show();
						break;
					case SmsManager.RESULT_ERROR_NO_SERVICE:
						Toast.makeText(getBaseContext(), "SMS: No service", Toast.LENGTH_SHORT).show();
						break;
					case SmsManager.RESULT_ERROR_NULL_PDU:
						Toast.makeText(getBaseContext(), "SMS: Null PDU", Toast.LENGTH_SHORT).show();
						break;
					case SmsManager.RESULT_ERROR_RADIO_OFF:
						Toast.makeText(getBaseContext(), "SMS: Radio off", Toast.LENGTH_SHORT).show();
						break;
				}
				unregisterReceiver(br);
			}
		};

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}

}
