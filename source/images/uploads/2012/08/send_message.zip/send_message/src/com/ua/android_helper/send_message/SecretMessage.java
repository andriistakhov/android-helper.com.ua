package com.ua.android_helper.send_message;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class SecretMessage extends Activity {
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.secret);
		// Get the extra data
		Bundle extras = getIntent().getExtras();
		String address = extras.getString("address");
		String message = extras.getString("message");

		TextView addresstv = (TextView) findViewById(R.id.addresstv);
		TextView messagetv = (TextView) findViewById(R.id.messagetv);

		messagetv.setText(message);
		addresstv.setText(address);
	}
}
