/** Automatically generated file. DO NOT MODIFY */
package com.ua.android_helper.send_message;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}