package com.android_helper.SplitActivityAnimation;

import android.app.Activity;
import android.os.Bundle;

import com.android_helper.SplitActivityAnimation.utils.SplitAnimation;

public class Activity2 extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Preparing the 2 images to be split
        SplitAnimation.prepareAnimation(this);

        setContentView(R.layout.act_two);

        // Animating the items to be open, revealing the new activity
        SplitAnimation.animate(this, 2000);
    }

    @Override
    protected void onStop() {
        // If we're currently running the entrance animation - cancel it
        SplitAnimation.cancel();

        super.onStop();    //To change body of overridden methods use File | Settings | File Templates.
    }
}
