/** Automatically generated file. DO NOT MODIFY */
package com.android_helper.SplitActivityAnimation;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}