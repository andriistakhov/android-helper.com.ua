package com.example.markup.tutorial;

import org.xml.sax.XMLReader;
import android.os.Bundle;
import android.app.Activity;
import android.graphics.drawable.Drawable;
import android.text.Editable;
import android.text.Html;
import android.text.Spannable;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.widget.TextView;

public class MainActivity extends Activity {

	TextView tvContent;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        tvContent = (TextView)findViewById(R.id.tvContent);
        tvContent.setLinksClickable(true);
        tvContent.setMovementMethod(new LinkMovementMethod());
        
        setArticle("article_main");
    }

    void setArticle(String strArticleResId) {
    	int articleResId = getResources().getIdentifier(strArticleResId, "string", getPackageName());
    	String text = getString(articleResId);
    	if (text == null) text = "Article not found";
    	
    	Spanned spannedText = Html.fromHtml(text, htmlImageGetter, htmlTagHandler);
    	Spannable reversedText = revertSpanned(spannedText);
    	
    	tvContent.setText(reversedText);
    }
    
    final Spannable revertSpanned(Spanned stext) {
        Object[] spans = stext.getSpans(0, stext.length(), Object.class);
        Spannable ret = Spannable.Factory.getInstance().newSpannable(stext.toString());
        if (spans != null && spans.length > 0) {
            for(int i = spans.length - 1; i >= 0; --i) {
                ret.setSpan(spans[i], stext.getSpanStart(spans[i]), stext.getSpanEnd(spans[i]), stext.getSpanFlags(spans[i]));
            }
        }

        return ret;
    }
    
    Html.ImageGetter htmlImageGetter = new Html.ImageGetter() {
		public Drawable getDrawable(String source) {
			int resId = getResources().getIdentifier(source, "drawable", getPackageName());
			Drawable ret = MainActivity.this.getResources().getDrawable(resId);
			ret.setBounds(0, 0, ret.getIntrinsicWidth(), ret.getIntrinsicHeight());
			return ret;
		}
	};

	Html.TagHandler htmlTagHandler = new Html.TagHandler() {
		public void handleTag(boolean opening, String tag, Editable output,	XMLReader xmlReader) {
			Object span = null;
			if (tag.startsWith("article_")) span = new ArticleSpan(MainActivity.this, tag);
			else if ("title".equalsIgnoreCase(tag)) span = new AppearanceSpan(0xffff2020, AppearanceSpan.NONE, 20, true, true, false, false);
			else if (tag.startsWith("color_")) span = new ParameterizedSpan(tag.substring(6));
			if (span != null) processSpan(opening, output, span);
		}
	};
	
	void processSpan(boolean opening, Editable output, Object span) {
		int len = output.length();
		if (opening) {
			output.setSpan(span, len, len, Spannable.SPAN_MARK_MARK);
		} else {
			Object[] objs = output.getSpans(0, len, span.getClass());
			int where = len;
			if (objs.length > 0) {
				for(int i = objs.length - 1; i >= 0; --i) {
					if (output.getSpanFlags(objs[i]) == Spannable.SPAN_MARK_MARK) {
						where = output.getSpanStart(objs[i]);
						output.removeSpan(objs[i]);
						break;
					}
				}
			}
			
			if (where != len) {
				output.setSpan(span, where, len, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
			}
		}
	}
	
}
