package com.example.markup.tutorial;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.net.Uri;
import android.os.Bundle;

public class AnotherActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    
        Uri uri = getIntent().getData();
        
        String caption = uri.getQueryParameter("caption");
        String text = uri.getQueryParameter("text");
        
        new AlertDialog.Builder(this)
        	.setTitle(caption)
        	.setMessage(text)
        	.setPositiveButton("OK", dioclOK)
        	.setCancelable(false)
        	.create().show();
    }
    
    DialogInterface.OnClickListener dioclOK = new DialogInterface.OnClickListener() {
		
		public void onClick(DialogInterface dialog, int which) {
			dialog.dismiss();
			finish();
		}
	};
    
}
