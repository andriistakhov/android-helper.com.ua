package com.example.widget;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.app.PendingIntent;
import android.app.Service;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.os.IBinder;
import android.text.format.Time;
import android.util.Log;
import android.widget.RemoteViews;

import com.example.widget.SimpleWikiHelper.ApiException;
import com.example.widget.SimpleWikiHelper.ParseException;

public class WordWidget extends AppWidgetProvider {
	@Override
	public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
		// Чтобы предотвратить любые ANR таймацты, мы выполняем обновление в сервисе.
		context.startService(new Intent(context, UpdateService.class));
	}

	public static class UpdateService extends Service {
		@Override
		public void onStart(Intent intent, int startId) {
			// Выполняем сегодняшнее обновление виджета.
			RemoteViews updateViews = buildUpdate(this);

			// Помещаем обновление этого выджета на домашний экран
			ComponentName thisWidget = new ComponentName(this, WordWidget.class);
			AppWidgetManager manager = AppWidgetManager.getInstance(this);
			manager.updateAppWidget(thisWidget, updateViews);
		}

		/**
		 * Строим обновление виджета, чтобы показать текущее слово. Заблокируем пока не получим online ответ.
		 */
		public RemoteViews buildUpdate(Context context) {
			// Берем название месяца из ресурсов
			Resources res = context.getResources();
			String[] monthNames = res.getStringArray(R.array.month_names);

			// ищем текущий месяц и день
			Time today = new Time();
			today.setToNow();

			// Заголовок страницы в вмде "Wiktionary:Word of the day/March 21"
			String pageName = res.getString(R.string.template_wotd_title, monthNames[today.month], today.monthDay);
			RemoteViews updateViews = null;
			String pageContent = "";

			try {
				// Пытаемся послать запрос Wiktionary API для получения слова дня
				SimpleWikiHelper.prepareUserAgent(context);
				pageContent = SimpleWikiHelper.getPageContent(pageName, false);
			} catch (ApiException e) {
				Log.e("WordWidget", "Couldn't contact API", e);
			} catch (ParseException e) {
				Log.e("WordWidget", "Couldn't parse API response", e);
			}

			// Используем регулярное выражение для парсинга слов и их описания
			Pattern pattern = Pattern.compile(SimpleWikiHelper.WORD_OF_DAY_REGEX);
			Matcher matcher = pattern.matcher(pageContent);
			if (matcher.find()) {
				// Выполняем обновление контента виджета
				updateViews = new RemoteViews(context.getPackageName(), R.layout.widget_word);

				String wordTitle = matcher.group(1);
				updateViews.setTextViewText(R.id.word_title, wordTitle);
				updateViews.setTextViewText(R.id.word_type, matcher.group(2));
				updateViews.setTextViewText(R.id.definition, matcher.group(3).trim());

				// Когда пользователь кликает на виджет, запускается страница Wiktionary.
				String definePage = res.getString(R.string.template_define_url, Uri.encode(wordTitle));
				Intent defineIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(definePage));
				PendingIntent pendingIntent = PendingIntent.getActivity(context, 0 /* no requestCode */, defineIntent,
						0 /* no flags */);
				updateViews.setOnClickPendingIntent(R.id.widget, pendingIntent);

			} else {
				// Слово дня не найдено, показываем ошибку
				updateViews = new RemoteViews(context.getPackageName(), R.layout.widget_message);
				CharSequence errorMessage = context.getText(R.string.widget_error);
				updateViews.setTextViewText(R.id.message, errorMessage);
			}
			return updateViews;
		}

		@Override
		public IBinder onBind(Intent intent) {
			// Мы не хотим привязываться к этому сервису
			return null;
		}
	}
}
