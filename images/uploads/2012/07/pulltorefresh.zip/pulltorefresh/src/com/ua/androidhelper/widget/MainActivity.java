package com.ua.androidhelper.widget;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.ViewGroup.LayoutParams;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;

public class MainActivity extends Activity {
	private final String[] values = { "Test 1", "Test 2", "Test 3", "Test 4", "Test 5", "Test 6", "Test 7", "Test 8",
			"Test 1", "Test 2", "Test 3", "Test 4", "Test 5", "Test 6", "Test 7", "Test 8", "Test 1", "Test 2",
			"Test 3", "Test 4", "Test 5", "Test 6", "Test 7", "Test 8", "Test 1", "Test 2", "Test 3", "Test 4",
			"Test 5", "Test 6", "Test 7", "Test 8" };

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// setContentView(R.layout.activity_main);

		ListAdapter adapter = new ArrayAdapter<String>(this, R.layout.list_item, values);
		PullToRefreshListView listView = new PullToRefreshListView(this);
		listView.setAdapter(adapter);
		setContentView(listView, new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT));
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}

}
