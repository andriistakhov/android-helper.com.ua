package com.android_helper.ActionBarNotification;

import android.app.ActionBar;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;

public class MyActivity extends Activity implements View.OnClickListener {
    private ViewGroup notificationBar;
    private ViewGroup content;
    private int statusBarHeight;

    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActionBar actionBar = getActionBar();
        actionBar.setDisplayOptions(ActionBar.DISPLAY_SHOW_HOME
                | ActionBar.DISPLAY_SHOW_TITLE | ActionBar.DISPLAY_SHOW_CUSTOM);

        setContentView(R.layout.main);

        prepareNotificationBar();

        initButtons();
    }

    private void initButtons() {
        Button button = (Button) findViewById(R.id.btn_error);
        button.setOnClickListener(this);

        button = (Button) findViewById(R.id.btn_info);
        button.setOnClickListener(this);

        button = (Button) findViewById(R.id.btn_hide);
        button.setOnClickListener(this);

        button = (Button) findViewById(R.id.btn_show);
        button.setOnClickListener(this);
    }

    private void prepareNotificationBar() {
        android.view.Window window = getWindow();

        // Получаем полное строенние вашего приложения
        ViewGroup decor = (ViewGroup) window.getDecorView();
        // Берем первый элемент, это то что было построенно
        View allcontent = decor.getChildAt(0);
        // Удаляем его что бы очистить строение
        decor.removeView(allcontent);

        LayoutInflater li = getLayoutInflater();
        // загружаем части элементов
        FrameLayout main = (FrameLayout) li.inflate(R.layout.content_frame, null);
        FrameLayout notificationFrame = (FrameLayout) li.inflate(R.layout.notification_frame, null);
        // находим нужные нам фреймы
        notificationBar = (ViewGroup) main.findViewById(R.id.notificationLayout);
        content = (ViewGroup) main.findViewById(R.id.contentLayout);

        // ВАЖНО! получаем высоту статус бара
        // -----
        int resourceId = getResources().getIdentifier("status_bar_height", "dimen", "android");

        statusBarHeight = 0;

        if (resourceId > 0) {
            statusBarHeight = getResources().getDimensionPixelSize(resourceId);
        }
        // -----

        // Сдвигаем наши фреймы на высоту статус бара
        notificationBar.setPadding(notificationBar.getPaddingLeft(), statusBarHeight, notificationBar.getPaddingRight(),
                0);
        notificationBar.addView(notificationFrame);

        content.setPadding(content.getPaddingLeft(), statusBarHeight, content.getPaddingRight(),
                0);

        // добавляем фреймы
        content.addView(allcontent);
        decor.addView(main);
    }

    @Override
    public void onClick(View v) {
        TextView textView = (TextView) notificationBar.findViewById(R.id.notification_text);
        switch (v.getId()) {
            case R.id.btn_error:
                textView.setBackgroundColor(Color.RED);
                break;
            case R.id.btn_info:
                textView.setBackgroundColor(Color.GREEN);
                break;
            case R.id.btn_show:
                notificationBar.setVisibility(View.VISIBLE);
                content.setPadding(content.getPaddingLeft(), statusBarHeight, content.getPaddingRight(),
                        0);
                break;
            case R.id.btn_hide:
                notificationBar.setVisibility(View.GONE);

                content.setPadding(content.getPaddingLeft(), 0, content.getPaddingRight(),
                        0);
                break;
        }
    }
}
