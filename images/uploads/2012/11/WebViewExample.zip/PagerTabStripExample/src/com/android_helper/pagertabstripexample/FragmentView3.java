package com.android_helper.pagertabstripexample;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class FragmentView3 extends Fragment {
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View myView = inflater.inflate(R.layout.fragment_web, container, false);
		WebView mWebView = (WebView) myView.findViewById(R.id.web);

		WebSettings settings = mWebView.getSettings();
		settings.setJavaScriptEnabled(true);
		settings.setDefaultTextEncodingName("utf-8");
		settings.setDefaultZoom(WebSettings.ZoomDensity.MEDIUM);

		mWebView.loadUrl("file:///android_asset/www/index.html");
		return myView;
	}

}
