package com.ua.android_helper;

import java.util.ArrayList;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.TabHost.TabContentFactory;
import android.widget.TabHost.TabSpec;
import android.widget.TabWidget;
import android.widget.TextView;

public class MainActivity extends FragmentActivity {

	private TabHost mTabHost;
	private ViewPager mViewPager;
	private TabsAdapter mTabsAdapter;

	@Override
	public void onCreate(final Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		mTabHost = (TabHost) findViewById(android.R.id.tabhost);
		mTabHost.setup();

		mViewPager = (ViewPager) findViewById(R.id.pager);

		mTabsAdapter = new TabsAdapter(this, mTabHost, mViewPager);

		// mTabsAdapter.addTab(mTabHost.newTabSpec("simple").setIndicator("Android"), AndroidFragment.class, null);
		// mTabsAdapter.addTab(mTabHost.newTabSpec("contacts").setIndicator("IOs"), IOsFragment.class, null);
		// mTabsAdapter.addTab(mTabHost.newTabSpec("custom").setIndicator("Windows"), WindowsFragment.class, null);
		// mTabsAdapter.addTab(mTabHost.newTabSpec("throttle").setIndicator("DOS"), DOSFragment.class, null);

		mTabsAdapter.addTab(setupTab(new TextView(this), "Android", R.drawable.bottom_selector, 0),
				AndroidFragment.class, null);
		mTabsAdapter
				.addTab(setupTab(new TextView(this), "IOs", R.drawable.bottom_selector, 0), IOsFragment.class, null);
		mTabsAdapter.addTab(setupTab(new TextView(this), "Windows", R.drawable.bottom_selector, 0),
				WindowsFragment.class, null);
		mTabsAdapter
				.addTab(setupTab(new TextView(this), "DOS", R.drawable.bottom_selector, 0), DOSFragment.class, null);

		if (savedInstanceState != null) {
			mTabHost.setCurrentTabByTag(savedInstanceState.getString("tab"));
		}

		// ������� ��� Windows - 15 ������������ ���������
		mTabsAdapter.updateNotification(15, 2);
	}

	private TabSpec setupTab(final View view, final String tag, final int imageRes, final int notificationItem) {
		View tabview = createTabView(mTabHost.getContext(), tag, imageRes, notificationItem);
		TabSpec setContent = mTabHost.newTabSpec(tag).setIndicator(tabview).setContent(new TabContentFactory() {
			@Override
			public View createTabContent(final String tag) {
				return view;
			}
		});
		// mTabHost.addTab(setContent);
		return setContent;
	}

	/**
	 * Creates the tab view.
	 * 
	 * @param context
	 *            the context
	 * @param text
	 *            the text
	 * @param imageRes
	 *            the image res
	 * @param notificationItem
	 *            the notification item
	 * @return the view
	 */
	private static View createTabView(final Context context, final String text, final int imageRes,
			final int notificationItem) {
		View view = LayoutInflater.from(context).inflate(R.layout.tab_host_layout, null);
		TextView tv = (TextView) view.findViewById(R.id.tab_text);
		tv.setText(text);
		ImageView iv = (ImageView) view.findViewById(R.id.tab_image);
		iv.setImageResource(imageRes);
		tv = (TextView) view.findViewById(R.id.tab_unread_message);
		tv.setText(String.valueOf(notificationItem));
		if (notificationItem == 0) {
			tv.setVisibility(View.GONE);
		} else {
			tv.setVisibility(View.VISIBLE);
		}
		return view;
	}

	public static class TabsAdapter extends FragmentPagerAdapter implements TabHost.OnTabChangeListener,
			ViewPager.OnPageChangeListener {
		private final Context mContext;
		private final TabHost mTabHost;
		private final ViewPager mViewPager;
		private final ArrayList<TabInfo> mTabs = new ArrayList<TabInfo>();

		static final class TabInfo {
			private final String tag;
			private final Class<?> clss;
			private final Bundle args;

			TabInfo(final String _tag, final Class<?> _class, final Bundle _args) {
				tag = _tag;
				clss = _class;
				args = _args;
			}
		}

		static class DummyTabFactory implements TabHost.TabContentFactory {
			private final Context mContext;

			public DummyTabFactory(final Context context) {
				mContext = context;
			}

			@Override
			public View createTabContent(final String tag) {
				View v = new View(mContext);
				v.setMinimumWidth(0);
				v.setMinimumHeight(0);
				return v;
			}
		}

		public TabsAdapter(final FragmentActivity activity, final TabHost tabHost, final ViewPager pager) {
			super(activity.getSupportFragmentManager());
			mContext = activity;
			mTabHost = tabHost;
			mViewPager = pager;
			mTabHost.setOnTabChangedListener(this);
			mViewPager.setAdapter(this);
			mViewPager.setOnPageChangeListener(this);
		}

		public void addTab(final TabHost.TabSpec tabSpec, final Class<?> clss, final Bundle args) {
			tabSpec.setContent(new DummyTabFactory(mContext));
			String tag = tabSpec.getTag();

			TabInfo info = new TabInfo(tag, clss, args);
			mTabs.add(info);
			mTabHost.addTab(tabSpec);
			notifyDataSetChanged();
		}

		@Override
		public int getCount() {
			return mTabs.size();
		}

		@Override
		public Fragment getItem(final int position) {
			TabInfo info = mTabs.get(position);
			return Fragment.instantiate(mContext, info.clss.getName(), info.args);
		}

		@Override
		public void onTabChanged(final String tabId) {
			int position = mTabHost.getCurrentTab();
			mViewPager.setCurrentItem(position);
		}

		@Override
		public void onPageScrolled(final int position, final float positionOffset, final int positionOffsetPixels) {
		}

		@Override
		public void onPageSelected(final int position) {
			// Unfortunately when TabHost changes the current tab, it kindly
			// also takes care of putting focus on it when not in touch mode.
			// The jerk.
			// This hack tries to prevent this from pulling focus out of our
			// ViewPager.
			TabWidget widget = mTabHost.getTabWidget();
			int oldFocusability = widget.getDescendantFocusability();
			widget.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
			mTabHost.setCurrentTab(position);
			widget.setDescendantFocusability(oldFocusability);
		}

		@Override
		public void onPageScrollStateChanged(final int state) {
		}

		public void updateNotification(final int notificationItem, final int position) {
			View view = mTabHost.getTabWidget().getChildAt(position);
			TextView tv = (TextView) view.findViewById(R.id.tab_unread_message);
			tv.setText(String.valueOf(notificationItem));
			if (notificationItem == 0) {
				tv.setVisibility(View.GONE);
			} else {
				tv.setVisibility(View.VISIBLE);
			}
		}
	}
}
